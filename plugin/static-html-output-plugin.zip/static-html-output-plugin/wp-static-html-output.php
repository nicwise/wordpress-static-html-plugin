<?php
/*
Plugin Name: WP Static HTML Output
Plugin URI:  https://leonstafford.github.io
Description: Benefit from WordPress as a CMS but with the speed, performance and portability of a static site
Version:     2.2
Author:      Leon Stafford
Author URI:  https://leonstafford.github.io
Text Domain: static-html-output-plugin

Copyright (c) 2017 Leon Stafford
 */

// use dropbox sdk lib composer fake autoload
require_once 'library/dropboxsdk/autoload.php';
require_once 'library/Github/autoload.php';
require_once 'library/StaticHtmlOutput/Options.php';
require_once 'library/StaticHtmlOutput/View.php';
require_once 'library/StaticHtmlOutput/UrlRequest.php';
require_once 'library/StaticHtmlOutput.php';

StaticHtmlOutput::init(__FILE__);

function pluginActionLinks($links) {
	$settings_link = '<a href="tools.php?page=wp-static-html-output-options">' . __('Settings', 'static-html-output-plugin') . '</a>'; 
  	array_unshift( $links, $settings_link ); 
  	return $links; 	
}	

function initialise_localisation() {
    load_plugin_textdomain( 'static-html-output-plugin', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' ); 
}

add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'pluginActionLinks');
add_action('plugins_loaded', 'initialise_localisation');
add_action( 'wp_ajax_generate_archive', 'generate_archive' );
add_action( 'wp_ajax_github_export', 'github_export' );
add_action( 'wp_ajax_github_finalise_export', 'github_finalise_export' );

function generate_archive() {
    $plugin = StaticHtmlOutput::getInstance();
    $plugin->genArch();
    wp_die();
}

function github_export() {
    $plugin = StaticHtmlOutput::getInstance();
    $plugin->githubExport();
    wp_die();
}

function github_finalise_export() {
    $plugin = StaticHtmlOutput::getInstance();
    $plugin->githubFinaliseExport();
    wp_die();
}
