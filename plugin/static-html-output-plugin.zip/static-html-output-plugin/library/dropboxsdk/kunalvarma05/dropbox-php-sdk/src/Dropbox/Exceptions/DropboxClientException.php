<?php
namespace Kunnu\Dropbox\Exceptions;

use Exception;

/**
 * DropboxClientException
 */
class DropboxClientException extends Exception
{
}
